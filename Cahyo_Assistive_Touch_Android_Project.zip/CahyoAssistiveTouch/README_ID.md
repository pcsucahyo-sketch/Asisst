# Cahyo Assistive Touch

Aplikasi Android sederhana untuk Redmi Note 8 Pro / Android 11.

## Fitur
- Bola pintas mengambang yang bisa dipindahkan.
- Kunci layar melalui AccessibilityService (`GLOBAL_ACTION_LOCK_SCREEN`).
- Volume media naik/turun melalui `AudioManager`.

## Persyaratan
- Android Studio (disarankan versi Giraffe atau lebih baru).
- JDK 17.
- Android SDK Platform 34 dan Build Tools yang sesuai.
- Tidak memerlukan root.

## Cara membuka dan membangun
1. Ekstrak ZIP ini.
2. Buka Android Studio > Open, pilih folder `CahyoAssistiveTouch`.
3. Tunggu Gradle Sync selesai.
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya tersedia di `app/build/outputs/apk/debug/app-debug.apk`.

## Cara mengaktifkan di HP
1. Instal APK.
2. Buka Cahyo Assistive Touch.
3. Tekan izin tampilan di atas aplikasi lain, lalu aktifkan izinnya.
4. Kembali ke aplikasi dan tekan tombol aksesibilitas. Cari Cahyo Assistive Touch pada daftar layanan yang diunduh dan aktifkan.
5. Kembali ke aplikasi, tekan Mulai Bola Pintas.
6. Ketuk bola biru untuk membuka menu.

## Catatan izin dan privasi
- Overlay dibutuhkan agar bola pintas tampil di atas aplikasi lain.
- AccessibilityService dipakai hanya untuk aksi kunci layar. Kode tidak mengambil teks layar, mengetik, atau mengirim data.
- Volume mengatur STREAM_MUSIC (media), bukan nada dering atau alarm.
- Kunci layar mengunci perangkat; tidak mematikan atau me-restart HP.
- Pada MIUI, jika layanan berhenti di latar belakang, izinkan Autostart dan nonaktifkan pembatasan baterai untuk aplikasi ini melalui pengaturan aplikasi.

## Batasan
Ini adalah proyek sumber awal, bukan APK yang sudah dikompilasi atau diuji pada perangkat fisik. Build perlu dilakukan di Android Studio. Android/MIUI dapat menampilkan dialog atau perilaku izin yang sedikit berbeda.
