package com.cahyo.assistivetouch

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var menu: LinearLayout? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var menuParams: WindowManager.LayoutParams? = null
    private var downX = 0
    private var downY = 0
    private var startX = 0
    private var startY = 0
    private var moved = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26)
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    else WindowManager.LayoutParams.TYPE_PHONE

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createBubble()
    }

    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, overlayType(),
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun createBubble() {
        bubbleParams = params(dp(56), dp(56)).apply {
            x = dp(12); y = dp(220)
        }
        bubble = TextView(this).apply {
            text = "●"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xDD2563EB.toInt())
                setStroke(dp(2), 0xAAFFFFFF.toInt())
            }
            elevation = dp(8).toFloat()
            setOnTouchListener { _, event ->
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.rawX.toInt(); downY = event.rawY.toInt()
                        startX = bubbleParams.x; startY = bubbleParams.y
                        moved = false
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX.toInt() - downX
                        val dy = event.rawY.toInt() - downY
                        if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                        bubbleParams.x = startX + dx
                        bubbleParams.y = startY + dy
                        wm.updateViewLayout(bubble, bubbleParams)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved) toggleMenu()
                        true
                    }
                    else -> false
                }
            }
        }
        wm.addView(bubble, bubbleParams)
    }

    private fun actionButton(label: String, action: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(0xFF1E293B.toInt())
            }
            setOnClickListener { action(); hideMenu() }
        }

    private fun toggleMenu() {
        if (menu != null) { hideMenu(); return }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(20).toFloat()
                setColor(0xEE0F172A.toInt())
                setStroke(dp(1), 0xFF64748B.toInt())
            }
        }
        panel.addView(actionButton("⏻  Kunci layar") {
            val service = LockAccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Aktifkan aksesibilitas Cahyo Assistive Touch terlebih dahulu", Toast.LENGTH_LONG).show()
            } else if (!service.lockScreen()) {
                Toast.makeText(this, "Perangkat tidak mengizinkan aksi kunci layar", Toast.LENGTH_SHORT).show()
            }
        }, rowParams())
        panel.addView(actionButton("＋  Volume naik") {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
        }, rowParams())
        panel.addView(actionButton("－  Volume turun") {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
        }, rowParams())
        panel.addView(actionButton("Tutup menu") { }, rowParams())

        menuParams = params(dp(210), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            x = (bubbleParams.x - dp(150)).coerceAtLeast(dp(4))
            y = (bubbleParams.y + dp(62)).coerceAtMost(resources.displayMetrics.heightPixels - dp(230))
        }
        menu = panel
        wm.addView(panel, menuParams)
    }

    private fun rowParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = dp(7) }

    private fun hideMenu() {
        menu?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        menu = null
        menuParams = null
    }

    override fun onDestroy() {
        hideMenu()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
