package com.cahyo.assistivetouch

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
        }

        val title = TextView(this).apply {
            text = "Cahyo Assistive Touch"
            textSize = 24f
            setTextColor(0xFF172554.toInt())
        }
        val info = TextView(this).apply {
            text = "\nKontrol tombol fisik melalui bola pintas.\n\n1. Izinkan tampil di atas aplikasi lain.\n2. Aktifkan layanan aksesibilitas untuk fungsi kunci layar.\n3. Tekan Mulai Bola Pintas."
            textSize = 16f
            setTextColor(0xFF333333.toInt())
        }
        val overlay = Button(this).apply {
            text = "1. Izinkan tampilan di atas aplikasi lain"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show()
            }
        }
        val accessibility = Button(this).apply {
            text = "2. Aktifkan aksesibilitas (Kunci layar)"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val start = Button(this).apply {
            text = "3. Mulai Bola Pintas"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Aktifkan izin overlay terlebih dahulu", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    Toast.makeText(this@MainActivity, "Bola pintas dijalankan", Toast.LENGTH_SHORT).show()
                }
            }
        }
        val stop = Button(this).apply {
            text = "Hentikan Bola Pintas"
            setOnClickListener { stopService(Intent(this@MainActivity, FloatingService::class.java)) }
        }

        listOf(title, info, overlay, accessibility, start, stop).forEach { view ->
            layout.addView(view, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                if (view is TextView && view === title) ViewGroup.LayoutParams.WRAP_CONTENT else ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(14) })
        }
        setContentView(layout)
    }
}
